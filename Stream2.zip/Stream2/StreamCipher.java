import java.io.*;

public class StreamCipher {

    public static void main (String []args) {
        // First step we are going to check the command line arguments.
        if (args.length != 3) {
            System.err.println("We have just three arguments in our stream cipher: key, inputFile and outputFile");
            System.exit(1);
        }
        // Here put the key as first argument.
        // Here we are going to validating a key value used in encryption and decryption.

        long seed;
        try {
            seed = Long.parseLong(args[0]);
        } catch (NumberFormatException number) {
            System.out.println("This is bad key");
            return;
        }

        if (seed == 0) {
            System.out.println("0 is not allowed as a key value");
            return;
        }

       // Create two objects, a BufferedReader and a BufferedWriter to read from and write to files specified in the command line arguments.
       // Process input file and write output file

        try (BufferedReader reader = new BufferedReader(new FileReader(args[1]));
             BufferedWriter writer = new BufferedWriter(new FileWriter(args[2]))) {
                
        // Initialize random generator.
            MyRandom random = new MyRandom(seed);

            int key;
            int encrypt;
            int decrypt;

            while ((encrypt = reader.read()) != -1) {
                key = random.next(8);
                decrypt = encrypt ^ key;
                writer.write(decrypt);
            }

        }catch (FileNotFoundException e) {
            System.err.println("File not found: " + e.getMessage());
            e.printStackTrace();
            return;
        } catch (IOException e) {
            System.err.println("IOException: " + e.getMessage());
            e.printStackTrace();
            return;
        }
    }
}
