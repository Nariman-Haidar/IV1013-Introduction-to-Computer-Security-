import java.util.Random;

public class MyRandom  extends Random{

    private static final long a = 19;
    private static final long b = 17;
    private static final long m = 9223372036854775643L;
    private long condition;

    // Creates a new random number generator
	public MyRandom() {
        condition = System.nanoTime();
	} 
	// Creates a new random number generator using a single long seed
	public MyRandom(long seed) {
		setSeed(seed);
	} 

	// Generates the next pseudorandom number.
    public int next(int bits) {
        condition = (a * condition) + b;
        condition %= m;
       // System.out.println(condition);
        return (int) (condition & (0xFFFF_FFFF_FFFFL >>> 48-bits));

   // return (int) (condition & (condition >>> bits));
    } 

    // Sets the seed of this random number generator using a single long seed.
	public void setSeed(long seed) {
		this.condition = seed; 
	} 
	
}
